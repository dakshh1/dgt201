let river;
let ripples = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  river = createGraphics(width, height);
  river.background(230, 240, 250);
  river.stroke(100, 150, 200, 100);
  river.strokeWeight(2);
  for (let i = 0; i < 500; i++) {
    river.point(random(width), random(height));
  }
}

function draw() {
  image(river, 0, 0);
  for (let r of ripples) {
    r.update();
    r.display();
  }
}

function mousePressed() {
  ripples.push(new Ripple(mouseX, mouseY));
}

class Ripple {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = 10;
    this.alpha = 255;
  }

  update() {
    this.radius += 1.5;
    this.alpha -= 2;
  }

  display() {
    noFill();
    stroke(100, 150, 250, this.alpha);
    strokeWeight(2);
    ellipse(this.x, this.y, this.radius * 2);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}